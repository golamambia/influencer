<?php
if($_POST){
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
require_once 'vendor/autoload.php';
require_once 'config/db.php';
require_once 'lib/pdo_db.php';
require_once 'models/Customer.php';
require_once 'models/Transaction.php';

\Stripe\Stripe::setApiKey('sk_test_9MKkBRFkikUjjiXbpv1mDxQ700FeDqmx5X');
  $subid_get=$_POST['sid'];
   $user=base64_decode($_POST['user']);
     $uid=$_POST['uid'];

    if($user==$uid){
		$customer = new Customer();

// Add Customer To DB
$get_data=$customer->getCustomerById($uid);

// if($get_data[0]->unsubscribe_plan>0){
	// $action="sub";
	
// }else{
	// $action="unsub";
// }


	//echo $customer->updateCustomerById($get_data[0]->id,$get_data[0]->customer_strip);
	// $subscription=\Stripe\Subscription::update(
  // $get_data[0]->subscription_id,
  // [
    // 'cancel_at_period_end' => true,
  // ]
// );

//echo $get_data[0]->id;
//echo  $customer->updateCustomerById($get_data[0]->id,$get_data[0]->customer_strip); 
	
$subscription = \Stripe\Subscription::retrieve($get_data[0]->subscription_id);
 $can=$subscription->cancel();
 if($can){
	echo $customer->updateCustomerById($get_data[0]->id,$get_data[0]->customer_strip); 
	 
 }else{
	echo"wrong";
}
 

}else{
	echo"wrong";
}
}else{
  header('Location:http://13.233.142.134');
 

}