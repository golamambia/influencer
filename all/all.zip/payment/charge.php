<?php
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);
error_reporting(0);
session_start();
require_once 'vendor/autoload.php';
require_once 'config/db.php';
require_once 'lib/pdo_db.php';
require_once 'models/Customer.php';
require_once 'models/Transaction.php';

\Stripe\Stripe::setApiKey('sk_test_9MKkBRFkikUjjiXbpv1mDxQ700FeDqmx5X');

// Sanitize POST Array
$POST = filter_var_array($_POST, FILTER_SANITIZE_STRING);
$customer_price = new Customer();
  $first_name = $_SESSION['data']['name'];
$last_name  = $_SESSION['data']['name'];
$email      = $POST['email'];
$token      = $POST['stripeToken'];
if($_SESSION['data']['name']!='' && $_SESSION['data']['email']!='' && $_SESSION['data']['phone']!='free_user' && $_SESSION['data']['subscribe']!='' && $_SESSION['data']['password']!=''){

  //print_r($_SESSION['data']);
//exit();
//$_SESSION['data'];

   $pack=base64_decode($_SESSION['data']['subscribe']);
//echo"<br>";

$pack_price =$customer_price->getPrice($pack);
 //echo $pack_price[0]->pamount;
  $pk_amount=$pack_price[0]->pamount*100;
  
 $pk_title=$pack_price[0]->ptitle;

// Create Customer In Stripe
$customer = \Stripe\Customer::create(array(
    "email"  => $_SESSION['data']['email'],
    "source" => $token,
));

$plan = \Stripe\Plan::create(array(
      "product" => [
          "name" => $first_name,
          "type" => "service"
      ],
      "nickname" => $first_name,
      "interval" => "month",
      "interval_count" => "1",
      "currency" => "usd",
      "amount" => $pk_amount,
  ));


// Charge Customer
$charge = \Stripe\Charge::create(array(
    "amount"      => $plan->amount,
    "currency"    => $plan->currency,
    "description" => $pk_title,
    "customer"    => $customer->id,
));

// Customer Data


$subscription = \Stripe\Subscription::create(array(
      "customer" => $customer->id,
      "items" => array(
          array(
              "plan" => $plan->id,
          ),
      ),
  ));


$customerData = [
    'id'         => $charge->customer,
    'first_name' => $first_name,
    'last_name'  => $last_name,
    'name'      => $first_name,
    'plan_id'      => $plan->id,
    'subscription_id'      => $subscription->id,
    'email'      => $_SESSION['data']['email'],
    'phone'      => $_SESSION['data']['phone'],
    'pass'      => base64_encode($_SESSION['data']['password']),
    'status'      => 'Active',
    'subscribe_pack'      => $pack,
    'entry_date'      => date('Y-m-d'),
    

];


// Instantiate Customer
$customer = new Customer();

// Add Customer To DB
$cus_id=$customer->addCustomer($customerData);

// Transaction Data
$transactionData = [
    'id'          => $charge->id,
    'name'        => $first_name,
    'description' => 'Test Description',
    'email'       => $email,
    'customer_id' => $charge->customer,
    'product'     => $charge->description,
    'amount'      => $charge->amount,
    'currency'    => $charge->currency,
    'status'      => $charge->status,
    "address"     => ["city" => 'kolkata', "country" => 'India', "line1" => '263/6 RRM', "line2" => "", "postal_code" => '700008', "state" => 'West Bengal'],
];

// Instantiate Transaction
$transaction = new Transaction();

// Add Transaction To DB
$transaction->addTransaction($transactionData);
if($cus_id){
$page_go="http://13.232.122.248/register/thankyou?tid=" . $charge->id . "&uid=" . $charge->customer. "&user=" . base64_encode($cus_id);
// Redirect to success
header('Location: ' .$page_go );
}else{
$page_go="http://13.232.122.248/register/failed?tid=".base64_encode('failed') ;
// Redirect to success
header('Location: ' .$page_go );
}

}else if($_SESSION['data']['name']!='' && $_SESSION['data']['email']!='' && $_SESSION['data']['phone']=='free_user' && $_SESSION['data']['subscribe']!='' && $_SESSION['data']['password']==''){


$pack=base64_decode($_SESSION['data']['subscribe']);
//echo"<br>";

$pack_price =$customer_price->getPrice($pack);
 //echo $pack_price[0]->pamount;
  $pk_amount=$pack_price[0]->pamount*100;
  
 $pk_title=$pack_price[0]->ptitle;

// Create Customer In Stripe
$customer = \Stripe\Customer::create(array(
    "email"  => $_SESSION['data']['email'],
    "source" => $token,
));

$plan = \Stripe\Plan::create(array(
      "product" => [
          "name" => $first_name,
          "type" => "service"
      ],
      "nickname" => $first_name,
      "interval" => "month",
      "interval_count" => "1",
      "currency" => "usd",
      "amount" => $pk_amount,
  ));


// Charge Customer
$charge = \Stripe\Charge::create(array(
    "amount"      => $plan->amount,
    "currency"    => $plan->currency,
    "description" => $pk_title,
    "customer"    => $customer->id,
));

// Customer Data


$subscription = \Stripe\Subscription::create(array(
      "customer" => $customer->id,
      "items" => array(
          array(
              "plan" => $plan->id,
          ),
      ),
  ));


$customerData = [
    'id'         => $charge->customer,
    'first_name' => $first_name,
    'last_name'  => $last_name,
    'name'      => $first_name,
    'plan_id'      => $plan->id,
    'subscription_id'      => $subscription->id,
    'email'      => $_SESSION['data']['email'],
    'phone'      => $_SESSION['data']['phone'],
    'pass'      => base64_encode($_SESSION['data']['password']),
    'pro_id'    => base64_decode($_SESSION['data']['pro_id']),
    'status'      => 'Active',
    'subscribe_pack'      => $pack,
    'entry_date'      => date('Y-m-d'),
    

];


// Instantiate Customer
$customer = new Customer();

// Add Customer To DB
$customer->updateCustomer($customerData);

// Transaction Data
$transactionData = [
    'id'          => $charge->id,
    'name'        => $first_name,
    'description' => 'Test Description',
    'email'       => $email,
    'customer_id' => $charge->customer,
    'product'     => $charge->description,
    'amount'      => $charge->amount,
    'currency'    => $charge->currency,
    'status'      => $charge->status,
    "address"     => ["city" => 'kolkata', "country" => 'India', "line1" => '263/6 RRM', "line2" => "", "postal_code" => '700008', "state" => 'West Bengal'],
];

// Instantiate Transaction
$transaction = new Transaction();

// Add Transaction To DB
$tchk=$transaction->addTransaction($transactionData);
if($tchk){
//$page_go="http://13.233.142.134/dashboard/subscribe?st=success";
// Redirect to success
//header('Location: ' .$page_go );
$page_go="http://13.232.122.248/dashboard/thankyou?tid=" . $charge->id . "&uid=" . $charge->customer. "&user=" . $_SESSION['data']['pro_id'];
// Redirect to success
header('Location: ' .$page_go );
}}
else if($_SESSION['data']['name']!='' && $_SESSION['data']['email']!='' && $_SESSION['data']['phone']=='upgrade' && $_SESSION['data']['subscribe']!='' && $_SESSION['data']['password']==''){


$pack=base64_decode($_SESSION['data']['subscribe']);
 $pack_pp=base64_decode($_SESSION['data']['subscribe_id']);
//exit();
//echo"<br>";
$pack_price_pp =$customer_price->getPrice($pack_pp);
$pack_price =$customer_price->getPriceUp($pack);
$pack_price_user =$customer_price->getCustomerById(base64_decode($_SESSION['data']['pro_id']));
 //echo $pack_price[0]->pamount;
  $pk_amount=$pack_price[0]->pamount*100;
  
 $pk_title=$pack_price[0]->ptitle;


 $now_search=$pack_price_user[0]->search_count-$pack_price[0]->psearch;
 $now_export=$pack_price_user[0]->export_count-$pack_price[0]->pexport;
 $now_dataid=$pack_price_user[0]->dataid_count-$pack_price[0]->pdataid;
//exit();
// Create Customer In Stripe
$customer = \Stripe\Customer::create(array(
    "email"  => $_SESSION['data']['email'],
    "source" => $token,
));



// Charge Customer
$charge = \Stripe\Charge::create(array(
    "amount"      => $pk_amount,
    "currency" => "usd",
    "description" => $pk_title,
    "customer"    => $customer->id,
));

// Customer Data


$customerData = [
    'id'         => $charge->customer,
    'first_name' => $first_name,
    'last_name'  => $last_name,
    'name'      => $first_name,
    'plan_id'      => 'no',
    'subscription_id'      => 'no',
    'email'      => $_SESSION['data']['email'],
    'phone'      => $_SESSION['data']['phone'],
    'now_search'      => $now_search,
    'pro_id'    => base64_decode($_SESSION['data']['pro_id']),
    'now_export'      => $now_export,
    'subscribe_pack'      => $pack,
    'dataid_count'      => $now_dataid,
    'entry_date'      => date('Y-m-d'),
    
];


// Instantiate Customer
$customer = new Customer();

// Add Customer To DB
$customer->updateCustomerUp($customerData);

// Transaction Data
$transactionData = [
    'id'          => $charge->id,
    'name'        => $first_name,
    'description' => $subscription->id,
    'email'       => $email,
    'customer_id' => base64_decode($_SESSION['data']['pro_id']),
    'product'     => $charge->description,
    'amount'      => $charge->amount,
    'currency'    => $charge->currency,
    'status'      => $charge->status,
	'subscribe_pack'      => $pack,
    "address"     => ["city" => 'kolkata', "country" => 'India', "line1" => '263/6 RRM', "line2" => "", "postal_code" => '700008', "state" => 'West Bengal'],
];

// Instantiate Transaction
$transaction = new Transaction();

// Add Transaction To DB
$tchk=$transaction->addTransactionUp($transactionData);
if($tchk){
$page_go="http://13.232.122.248/dashboard/upgrade_success?tid=".$charge->id ."&user=" . $_SESSION['data']['pro_id'];
// Redirect to success
header('Location: ' .$page_go );
}else{
 
  $page_go="http://13.232.122.248/dashboard/failed?tid=".base64_encode('failed');
// Redirect to success
header('Location: ' .$page_go );
}

}else{
$page_go="http://13.232.122.248/register/";
// Redirect to success
header('Location: ' .$page_go );
}


//exit();
