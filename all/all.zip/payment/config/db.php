<?php
  // DB Params
  define("DB_HOST", "localhost");
  define("DB_USER", "root");
  define("DB_PASS", "7RClhVgnnd19");
  define("DB_NAME", "influencer_db");