<?php
  class Customer {
    private $db;

    public function __construct() {
      $this->db = new Database;
    }
	public function getPrice($id) {
       $this->db->query('SELECT * FROM pricing_table where pid="'.$id.'" ');

      $results = $this->db->resultset();

      return $results;
    }
	
	public function getPriceUp($id) {
       $this->db->query('SELECT * FROM extra_plan where pid="'.$id.'" ');

      $results = $this->db->resultset();

      return $results;
    }
    public function addCustomer($data) {
      // Prepare Query
	  $rndate=date('Y-m-d', strtotime(' +1 months'));
      $this->db->query('INSERT INTO user_table (name, phone, email,pass,status,subscribe_pack,entry_date,user_photo,address,customer_strip,
	  search_count,export_count,plan_id,unsubscribe_plan,subscription_id,plan_date,renew_date,dataid_count) 
	  VALUES(:name, :phone, :email,:pass,:status,:subscribe_pack,:entry_date,:user_photo,:address,:customer_strip,:search_count,:export_count,
	  :plan_id,:unsubscribe_plan,:subscription_id,:plan_date,:renew_date,:dataid_count)');

      // Bind Values
      $this->db->bind(':name', $data['first_name']);
      $this->db->bind(':phone', $data['phone']);
      $this->db->bind(':email', $data['email']);
      $this->db->bind(':pass', $data['pass']);
      $this->db->bind(':status', $data['status']);
      $this->db->bind(':subscribe_pack', $data['subscribe_pack']);
      $this->db->bind(':entry_date', $data['entry_date']);
	  $this->db->bind(':user_photo', '');
	  $this->db->bind(':address', '');
	  
	  $this->db->bind(':customer_strip', $data['id']);
	  $this->db->bind(':search_count', 0);
      $this->db->bind(':export_count', 0);
      $this->db->bind(':unsubscribe_plan', 0);
      $this->db->bind(':plan_id',  $data['plan_id']);
      $this->db->bind(':subscription_id',  $data['subscription_id']);
	   $this->db->bind(':plan_date', $data['entry_date']);
	   $this->db->bind(':renew_date', date('Y-m-d', strtotime(' +1 months')));
	   $this->db->bind(':dataid_count',0);
      // Execute
      if($this->db->execute()) {
        //return true;
	return  $this->db->lastInsertId();
      } else {
        return false;
      }
    }
	
	public function updateCustomerUp($data) {
	$results =$this->db->query("update user_table set 
	search_count=:search_count,export_count=:export_count,dataid_count=:dataid_count where id=:id ");
				  
	  $this->db->bind(':id', $data['pro_id']);
	  $this->db->bind(':search_count', $data['now_search']);
      $this->db->bind(':export_count', $data['now_export']);
      $this->db->bind(':dataid_count', $data['dataid_count']);
	  
	  if($this->db->execute()){
		  return "success";
	  }else{
		  return "failed";
	  }
	  
	}
	
	
	public function updateCustomer($data) {
	$results =$this->db->query("update user_table set subscribe_pack=:subscribe_pack,plan_date=:plan_date,subscription_id=:subscription_id,
	plan_id=:plan_id,customer_strip=:customer_strip,search_count=:search_count,export_count=:export_count,renew_date=:renew_date,dataid_count=:dataid_count where id=:id ");
			
	  $this->db->bind(':subscribe_pack', $data['subscribe_pack']);
	  $this->db->bind(':subscription_id', $data['subscription_id']);
	  $this->db->bind(':plan_id', $data['plan_id']);
	  
	  $this->db->bind(':plan_date', date('Y-m-d'));
	  $this->db->bind(':customer_strip', $data['id']);
	  $this->db->bind(':id', $data['pro_id']);
	  $this->db->bind(':search_count', 0);
      $this->db->bind(':export_count', 0);
	  $this->db->bind(':renew_date', date('Y-m-d', strtotime(' +1 months')));
	  $this->db->bind(':dataid_count',0);
      
	  if($this->db->execute()){
		  return "success";
	  }else{
		  return "failed";
	  }
	  
	}
	
	

    public function getCustomers() {
      $this->db->query('SELECT * FROM customers ORDER BY created_at DESC');

      $results = $this->db->resultset();

      return $results;
    }
    public function getCustomerById($id){
      $this->db->query("SELECT * FROM user_table where id=".$id."");

      $results = $this->db->resultset();

      return $results;
    }
    public function updateCustomerById($id,$customer_strip){
      // $results =$this->db->query("update user_table set unsubscribe_plan=:unsubscribe_plan,plan_date=:plan_date where id=:id ");
			
	  // $this->db->bind(':unsubscribe_plan', $unsubscribe_plan);
	  // $this->db->bind(':plan_date', date('Y-m-d'));
	  // $this->db->bind(':id', $id);
      
	  // if($this->db->execute()){
		  // return "success";
	  // }else{
		  // return "failed";
	  // }
	  
	  $results =$this->db->query("update user_table set subscribe_pack=:subscribe_pack,plan_date=:plan_date,subscription_id=:subscription_id,
	plan_id=:plan_id,customer_strip=:customer_strip,search_count=:search_count,export_count=:export_count,renew_date=:renew_date,dataid_count=:dataid_count where id=:id ");
			
	  $this->db->bind(':subscribe_pack', 0);
	  $this->db->bind(':subscription_id', '');
	  $this->db->bind(':plan_id','');
	  
	  $this->db->bind(':plan_date',NULL);
	  $this->db->bind(':customer_strip', '');
	  $this->db->bind(':id', $id);
	  $this->db->bind(':search_count', 0);
      $this->db->bind(':export_count', 0);
	  $this->db->bind(':renew_date', date('Y-m-d', strtotime(' +1 months')));
	  $this->db->bind(':dataid_count',0);
	  //$this->db->debugDumpParams();
      //exit();
	  if($this->db->execute()){
		  
		  $del =$this->db->query("delete from transactions where customer_id=:customer_id ");
			
	   $this->db->bind(':customer_id', $customer_strip);
		  $this->db->execute();
		  
		  return "success";
	  }else{
		  return "failed";
	  }
	  
	  
	  
	  
      
    }



  }