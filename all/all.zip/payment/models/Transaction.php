<?php
  class Transaction {
    private $db;

    public function __construct() {
      $this->db = new Database;
    }

    public function addTransaction($data) {
      // Prepare Query
      $this->db->query('INSERT INTO transactions (charge_id, customer_id, product, amount, currency, status) VALUES(:charge_id, :customer_id, :product, :amount, :currency, :status)');

      // Bind Values
      $this->db->bind(':charge_id', $data['id']);
      $this->db->bind(':customer_id', $data['customer_id']);
      $this->db->bind(':product', $data['product']);
      $this->db->bind(':amount', $data['amount']/100);
      $this->db->bind(':currency', $data['currency']);
      $this->db->bind(':status', $data['status']);

      // Execute
      if($this->db->execute()) {
        return true;
      } else {
        return false;
      }
    }
	
	public function addTransactionUp($data) {
      // Prepare Query
      $this->db->query('INSERT INTO transactions_upgrade (charge_id, customer_id, product, amount, currency, status,subscriber_pack) 
	  VALUES(:charge_id, :customer_id, :product, :amount, :currency, :status,:subscriber_pack)');

      // Bind Values
      $this->db->bind(':charge_id', $data['id']);
      $this->db->bind(':customer_id', $data['customer_id']);
      $this->db->bind(':product', $data['product']);
      $this->db->bind(':amount', $data['amount']/100);
      $this->db->bind(':currency', $data['currency']);
      $this->db->bind(':status', $data['status']);
	   $this->db->bind(':subscriber_pack', $data['subscribe_pack']);

      // Execute
      if($this->db->execute()) {
        return true;
      } else {
        return false;
      }
    }

    public function getTransactions() {
      $this->db->query('SELECT * FROM transactions ORDER BY created_at DESC');

      $results = $this->db->resultset();

      return $results;
    }
  }