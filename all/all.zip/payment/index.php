<?php
session_start();
//print_r($_POST);
$_SESSION['data']=$_POST;
//define("base_url", "http://13.233.142.134/");
//echo base_url();
function base_url(){
	return "http://13.232.122.248/";
}
 print_r($_SESSION['dem']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="<?=base_url();?>assets_front/images/favicon.png" type="image/x-icon" />
    <title>INFLUENCERTABLE</title>
    <!-- Bootstrap -->
    <link href="<?=base_url();?>assets_front/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap&subset=cyrillic,cyrillic-ext,latin-ext,vietnamese" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" type="text/css">

    <link href="<?=base_url();?>assets_front/css/style.css" rel="stylesheet">
    <link href="<?=base_url();?>assets_front/css/responsive.css" rel="stylesheet">
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/css/select2.min.css'>
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

  <title>Pay Page</title>
</head>
<body>
<div class="header_top clearfix">
        <div class="container-fluid">
            <div class="logo">
               <a href="<?=base_url();?>"> <img src="<?=base_url();?>assets_front/images/logo.png" alt="logo"></a>
            </div>
            <div class="header_right">
                <nav class="menu">
                    <div class="menuButton">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <ul>
                       
                        <li><a href="<?=base_url();?>help">Need help with search?</a></li>
                        <li><a href="<?=base_url();?>pricing">Pricing</a></li>
                        
                    </ul>
                </nav>
                
            </div>
        </div>
    </div>




  <div class="container">
  <div class="payment_area">
    <h2 class="my-4 text-center">Pay amount <br><small class="amount">[$<?=$_POST['pay_amt'];?>]</small></h2>
    <form action="./charge.php" method="post" id="payment-form">
      <div class="form-row">
       <input type="hidden" name="name" class="form-control mb-3 StripeElement StripeElement--empty" placeholder="">
       <input type="hidden" name="email" class="form-control mb-3 StripeElement StripeElement--empty" placeholder="">
       <input type="hidden" name="phone" class="form-control mb-3 StripeElement StripeElement--empty" placeholder="">
       <input type="hidden" name="subscribe" class="form-control mb-3 StripeElement StripeElement--empty" placeholder="">
       <input type="hidden" name="password" class="form-control mb-3 StripeElement StripeElement--empty" placeholder="">
        <div id="card-element" class="form-control">
          <!-- a Stripe Element will be inserted here. -->
        </div>

        <!-- Used to display form errors -->

        <div id="card-errors" role="alert"></div>
      </div>

      <button>Pay now</button>
<a class="cancel_pay " href="<?=base_url();?>">Cancel</a>
    </form>
    </div>
  </div>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://js.stripe.com/v3/"></script>
  <script src="./js/charge.js"></script>
 <!-- footer css Start -->
    <footer class="footer_area">
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-lg-3">
                    <div class="footer">
                        <h3>Our Services</h3>
                        <ul>
                            <li><a href="<?=base_url();?>help">Need help with search?</a></li>
                            <li><a href="<?=base_url();?>pricing">Pricing</a></li>
                             
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="footer">
                        <h3>Contact</h3>
                        <ul>
                            <li><a href="mailto:info.influencertable.com">info.influencertable.com</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright">© 2020 <strong>INFLUENCERTABLE</strong> . All Right Reserved</div>
    </footer>
    <!-- footer css stop -->

    <!-- search area -->

    
               

    <script src="<?=base_url();?>assets_front/js/jquery.min.js"></script>
    <script src="<?=base_url();?>assets_front/js/popper.min.js"></script>
    <script src="<?=base_url();?>assets_front/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.cycle2/2.1.6/jquery.cycle2.min.js"></script>
    <script src="http://malsup.github.io/jquery.cycle2.scrollVert.js"></script>
    <script src="<?=base_url();?>assets_front/js/jquery.extra.js"></script>
	 <script src='https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/js/select2.min.js'></script>
    <script>
        jQuery(document).ready(function() {
            jQuery(".menu li").find("ul").parent().append("<span></span>");
            jQuery(".menuButton").click(function() {
                jQuery(".menuButton").toggleClass("arrow_change");
                jQuery(".menuButton + ul").slideToggle();
            });
            jQuery(".menu ul li span").click(function() {
                if (jQuery("span").parent().children("ul").is(":visible")) {
                    jQuery(this).parent().siblings().children("ul").slideUp();
                }
                jQuery(this).parent().children("ul").slideToggle();
            });

             $('.numeric_input').keydown(function(event) {
return ( event.ctrlKey || event.altKey 
                    || (47<event.keyCode && event.keyCode<58 && event.shiftKey==false) 
                    || (95<event.keyCode && event.keyCode<106)
                    || (event.keyCode==8) || (event.keyCode==9) 
                    || (event.keyCode>34 && event.keyCode<40) 
                    || (event.keyCode==46) )


      
    });
        });

        jQuery(".myAccount span").click(function() {
            jQuery(".myAccount span").toggleClass("arrow_change");
            jQuery(".myAccountDropdown").slideToggle();

        });

    </script>

<script>
       $(document).ready(function(){
  $(".tokenizationSelect2").select2({
		//placeholder: "Your favourite car", //placeholder
		tags: true,
		tokenSeparators: ['/',',',';'," "] 
	});
})

    </script>
</body>

</html>